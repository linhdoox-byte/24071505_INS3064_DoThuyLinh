/*
  File: university_queries.sql
  Author: Đỗ Thùy Linh
  Student ID: 24071506
  Assignment: Homework 5 - University Queries
  Date: 12/10/2026
*/

USE university_db;

/*
Query 1: List all students
Description: Retrieve all columns from the students table to see all registered students.
Expected Output: A table containing student IDs, names, emails, and GPAs.
 */
SELECT * 
FROM students;
/*
+----+-------------------+-----------------------+------+
| id | name              | email                 | gpa  |
+----+-------------------+-----------------------+------+
|  1 | Nguyen Van An     | an.nv@university.edu  | 3.50 |
|  2 | Tran Thi Bich     | bich.tt@university.edu| 3.80 |
+----+-------------------+-----------------------+------+
(2 rows)
*/
/*
Query 2: Students with High GPA
Description: Filters students who have a GPA greater than 3.2.
Expected Output: A list of students whose GPA > 3.2.
 */
SELECT id, name, gpa 
FROM students 
WHERE gpa > 3.2;
/*
Query 3: CS Courses with 3 or more credits
Description: Finds courses belonging to the Computer Science department (or specific dept_id) with credits >= 3.
Expected Output: Filtered list of courses matching department and credit criteria.
 */
SELECT course_code, title, credits 
FROM courses 
WHERE department_id = 1 AND credits >= 3;
/*
Query 4: Students Sorted by Name
Description: Lists all students ordered alphabetically by their name in ascending order.
Expected Output: Sorted student records by name.
 */
SELECT id, name, gpa 
FROM students 
ORDER BY name ASC;
/*
Query 5: Top 3 Highest GPA Students
Description: Returns only the top 3 students with the highest GPA.
Expected Output: Exactly 3 rows of students with the highest GPAs.
 */
SELECT id, name, gpa 
FROM students 
ORDER BY gpa DESC 
LIMIT 3;
/*
Query 6: Search Courses by Keyword
Description: Searches for courses whose titles contain the word "Introduction".
Expected Output: List of introductory courses.
 */
SELECT course_code, title 
FROM courses 
WHERE title LIKE '%Introduction%';
/*
Query 7: Total Credits of All Courses
Description: Uses the SUM aggregate function to calculate the total credits offered across all courses.
Expected Output: A single row displaying the total sum of credits.
 */
SELECT SUM(credits) AS total_course_credits 
FROM courses;
/*
Query 8: Departments with Multiple Courses
Description: Groups courses by department_id and filters departments offering more than 2 courses using HAVING.
Expected Output: List of department IDs and their course counts where count > 2.
 */
SELECT department_id, COUNT(*) AS course_count 
FROM courses 
GROUP BY department_id 
HAVING COUNT(*) > 2;
/*
Query 9: Courses with Instructor Names
Description: Joins the courses and instructors tables to show each course title alongside the instructor teaching it.
Expected Output: A list matching course titles with instructor names.
 */
SELECT 
    c.course_code,
    c.title AS course_title,
    CONCAT(i.first_name, ' ', i.last_name) AS instructor_name
FROM courses c
JOIN instructors i ON c.instructor_id = i.id
ORDER BY c.course_code;
/*
Query 10: Detailed Enrollments List
Description: A multi-table join connecting enrollments, students, and courses to show who is enrolled in which course.
Expected Output: A comprehensive list containing student names, course titles, and enrollment status/grades.
 */
SELECT 
    s.name AS student_name,
    c.title AS course_title,
    e.grade
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_id = c.id
ORDER BY s.name;