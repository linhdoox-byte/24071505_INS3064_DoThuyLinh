-- =====================================================================
-- Họ tên      : Đỗ Thùy Linh
-- Mã sinh viên: 24071506
-- Bài tập     : Homework 04 (INS3064)
-- Ngày        : 2026-10-05
-- Mô tả       : Tạo CSDL university_db, 6 bảng, ràng buộc và dữ liệu mẫu.
-- Yêu cầu     : MySQL 8.0.16+ (để CHECK constraint có hiệu lực)
DROP DATABASE IF EXISTS university_db;
CREATE DATABASE university_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;  
USE university_db;


DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS semesters;
DROP TABLE IF EXISTS departments;


CREATE TABLE departments (
    id          INT AUTO_INCREMENT PRIMARY KEY,               -- khóa chính tự tăng
    name        VARCHAR(100) NOT NULL UNIQUE,                 -- tên khoa, không trùng
    code        VARCHAR(10)  NOT NULL UNIQUE,                 -- mã khoa, không trùng
    description TEXT NULL,                                    -- mô tả dài
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP   -- thời điểm tạo
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Bảng semesters: các học kỳ (không có khóa ngoại)
-- ---------------------------------------------------------------------
CREATE TABLE semesters (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL UNIQUE,                  -- vd: Fall 2024
    start_date  DATE NOT NULL,
    end_date    DATE NOT NULL,
    CONSTRAINT chk_semester_dates CHECK (end_date > start_date) -- ngày kết thúc phải sau ngày bắt đầu
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Bảng instructors: giảng viên, thuộc 1 khoa (quan hệ 1-N)
-- ---------------------------------------------------------------------
CREATE TABLE instructors (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,               -- email duy nhất
    phone         VARCHAR(15)  NULL,
    hire_date     DATE NOT NULL DEFAULT (CURRENT_DATE),       -- ngày vào làm
    department_id INT NOT NULL,                               -- khoa của giảng viên
    CONSTRAINT fk_instructors_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE RESTRICT      -- không cho xóa khoa nếu còn giảng viên
        ON UPDATE CASCADE       -- đổi id khoa thì cập nhật theo
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Bảng students: sinh viên, thuộc 1 khoa (ngành học)
-- ---------------------------------------------------------------------
CREATE TABLE students (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    student_code  VARCHAR(15)  NOT NULL UNIQUE,               -- mã sinh viên duy nhất
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    gender        ENUM('male','female','other') NOT NULL DEFAULT 'other', -- tập giá trị cố định
    birth_date    DATE NULL,
    gpa           DECIMAL(3,2) NOT NULL DEFAULT 0.00,         -- vd 3.45 (thang 4)
    enrolled_year YEAR NOT NULL,                              -- năm nhập học
    department_id INT NOT NULL,                               -- ngành (khoa) của sinh viên
    CONSTRAINT chk_student_gpa CHECK (gpa BETWEEN 0.00 AND 4.00),
    CONSTRAINT fk_students_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Bảng courses: học phần, thuộc 1 khoa và do 1 giảng viên phụ trách
-- ---------------------------------------------------------------------
CREATE TABLE courses (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    course_code   VARCHAR(15)  NOT NULL UNIQUE,               -- mã học phần duy nhất
    title         VARCHAR(150) NOT NULL,
    description   TEXT NULL,
    credits       TINYINT NOT NULL DEFAULT 3,                 -- số tín chỉ
    department_id INT NOT NULL,
    instructor_id INT NULL,                                   -- cho phép NULL khi chưa phân công
    CONSTRAINT chk_course_credits CHECK (credits BETWEEN 1 AND 6),
    CONSTRAINT fk_courses_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_courses_instructor
        FOREIGN KEY (instructor_id) REFERENCES instructors(id)
        ON DELETE SET NULL      -- xóa giảng viên thì học phần chuyển về "chưa phân công"
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Bảng enrollments: bảng trung gian N-N giữa students và courses theo học kỳ
-- ---------------------------------------------------------------------
CREATE TABLE enrollments (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id      INT NOT NULL,
    course_id       INT NOT NULL,
    semester_id     INT NOT NULL,
    enrollment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    grade           DECIMAL(3,2) NULL,                        -- điểm hệ 4, NULL = chưa có điểm
    grade_letter    ENUM('A','B','C','D','F') NULL,           -- điểm chữ
    CONSTRAINT chk_enrollment_grade CHECK (grade IS NULL OR grade BETWEEN 0.00 AND 4.00),
    -- Một sinh viên không đăng ký trùng một học phần trong cùng học kỳ
    CONSTRAINT unique_enrollment UNIQUE (student_id, course_id, semester_id),
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) REFERENCES students(id)
        ON DELETE CASCADE       -- xóa sinh viên thì xóa luôn đăng ký của họ
        ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_course
        FOREIGN KEY (course_id) REFERENCES courses(id)
        ON DELETE RESTRICT      -- không xóa học phần đã có người đăng ký
        ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_semester
        FOREIGN KEY (semester_id) REFERENCES semesters(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- DỮ LIỆU MẪU (chèn theo thứ tự phụ thuộc)
-- =====================================================================

INSERT INTO departments (name, code, description) VALUES
('Công nghệ thông tin',        'CNTT', 'Đào tạo lập trình, cơ sở dữ liệu, trí tuệ nhân tạo'),
('Quản trị kinh doanh',        'QTKD', 'Đào tạo quản trị, marketing, phân tích kinh doanh'),
('Kế toán - Tài chính',        'KTTC', 'Đào tạo kế toán, kiểm toán, tài chính doanh nghiệp'),
('Ngôn ngữ Anh',               'NNA',  'Đào tạo tiếng Anh thương mại và biên phiên dịch'),
('Điện tử - Viễn thông',       'DTVT', 'Đào tạo điện tử, vi mạch, truyền thông số');

INSERT INTO semesters (name, start_date, end_date) VALUES
('Fall 2024',   '2024-09-01', '2024-12-31'),
('Spring 2025', '2025-01-15', '2025-05-31'),
('Summer 2025', '2025-06-10', '2025-08-15'),
('Fall 2025',   '2025-09-01', '2025-12-31'),
('Spring 2026', '2026-01-15', '2026-05-31');

INSERT INTO instructors (full_name, email, phone, hire_date, department_id) VALUES
('Nguyễn Văn Hùng',  'hung.nv@university.edu.vn',  '0901234567', '2015-08-20', 1),
('Trần Thị Mai',     'mai.tt@university.edu.vn',   '0912345678', '2017-03-15', 1),
('Lê Minh Quân',     'quan.lm@university.edu.vn',  '0923456789', '2012-09-01', 2),
('Phạm Thu Hà',      'ha.pt@university.edu.vn',    '0934567890', '2019-01-10', 3),
('Hoàng Đức Anh',    'anh.hd@university.edu.vn',   '0945678901', '2018-06-25', 4),
('Vũ Thanh Tùng',    'tung.vt@university.edu.vn',  '0956789012', '2020-02-05', 5);

INSERT INTO students (student_code, full_name, email, gender, birth_date, gpa, enrolled_year, department_id) VALUES
('SV2024001', 'Nguyễn Thị Linh',   'linh.nt@student.edu.vn',   'female', '2005-04-12', 3.65, 2024, 1),
('SV2024002', 'Trần Quốc Bảo',     'bao.tq@student.edu.vn',    'male',   '2005-08-30', 3.20, 2024, 1),
('SV2024003', 'Lê Hoàng Nam',      'nam.lh@student.edu.vn',    'male',   '2005-01-22', 2.85, 2024, 2),
('SV2024004', 'Phạm Ngọc Anh',     'anh.pn@student.edu.vn',    'female', '2005-11-05', 3.90, 2024, 2),
('SV2024005', 'Đỗ Minh Khôi',      'khoi.dm@student.edu.vn',   'male',   '2004-12-18', 2.40, 2024, 3),
('SV2024006', 'Vũ Thùy Dương',     'duong.vt@student.edu.vn',  'female', '2005-06-09', 3.45, 2024, 4),
('SV2024007', 'Bùi Anh Tuấn',      'tuan.ba@student.edu.vn',   'male',   '2005-03-27', 3.05, 2024, 5),
('SV2024008', 'Đặng Khánh Vy',     'vy.dk@student.edu.vn',     'female', '2005-09-14', 3.75, 2024, 1);

INSERT INTO courses (course_code, title, description, credits, department_id, instructor_id) VALUES
('CS201',  'Cấu trúc dữ liệu và giải thuật', 'Mảng, danh sách liên kết, cây, đồ thị, sắp xếp, tìm kiếm', 4, 1, 1),
('CS301',  'Cơ sở dữ liệu',                  'Mô hình quan hệ, SQL, chuẩn hóa, giao dịch',               3, 1, 2),
('CS350',  'Học máy cơ bản',                 'Hồi quy, phân loại, mạng nơ-ron, đánh giá mô hình',        3, 1, 1),
('BA101',  'Nguyên lý quản trị',             'Các chức năng của nhà quản trị và tổ chức doanh nghiệp',   3, 2, 3),
('BA210',  'Phân tích kinh doanh',           'Phân tích dữ liệu hỗ trợ ra quyết định kinh doanh',        3, 2, 3),
('FIN150', 'Kế toán tài chính',              'Nguyên tắc kế toán và lập báo cáo tài chính',              3, 3, 4),
('ENG120', 'Tiếng Anh thương mại',           'Giao tiếp và viết email trong môi trường kinh doanh',      2, 4, 5);

INSERT INTO enrollments (student_id, course_id, semester_id, grade, grade_letter) VALUES
(1, 1, 1, 3.70, 'A'),
(1, 2, 2, 3.50, 'A'),
(1, 3, 4, 3.30, 'B'),
(2, 1, 1, 3.00, 'B'),
(2, 2, 2, 2.80, 'B'),
(3, 4, 1, 2.50, 'C'),
(3, 5, 2, 2.90, 'B'),
(4, 4, 1, 4.00, 'A'),
(4, 5, 2, 3.80, 'A'),
(5, 6, 1, 2.00, 'C'),
(6, 7, 1, 3.50, 'A'),
(7, 2, 4, 3.10, 'B'),
(8, 1, 4, NULL, NULL),     -- chưa có điểm
(8, 3, 5, NULL, NULL);     -- đang học, chưa có điểm

-- =====================================================================
-- Câu lệnh kiểm tra nhanh (có thể chạy sau khi import)
-- =====================================================================
-- SELECT s.full_name, c.title, e.grade
-- FROM enrollments e
-- JOIN students s ON s.id = e.student_id
-- JOIN courses  c ON c.id = e.course_id;
